package calculadora;

import apresentacao.frmPrincipal;

public class Calculadora
{
    public static void main(String[] args)
    {
        frmPrincipal frmP = new frmPrincipal(null, true);
        frmP.setVisible(true);
    }
}
